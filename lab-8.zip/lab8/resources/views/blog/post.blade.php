@extends('layouts.master')

@section('content')
    <div class="row">
        <div class="col-md-12">
            <p class="quote">Learning Laravel</p>
        </div>
    </div>
    <div class="row">
        <div class="col-md-12 text-center">
            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptatem, nam unde consequuntur, ullam vero libero velit doloremque excepturi molestias numquam eum ex. Tenetur ullam delectus commodi obcaecati natus distinctio officiis.</p>
        </div>
    </div>
@endsection